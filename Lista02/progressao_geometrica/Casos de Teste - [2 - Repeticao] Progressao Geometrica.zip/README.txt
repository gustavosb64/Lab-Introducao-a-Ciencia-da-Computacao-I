Arquivo zip gerado em: 11/05/2021 17:07:51 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Repetição] Progressão Geométrica