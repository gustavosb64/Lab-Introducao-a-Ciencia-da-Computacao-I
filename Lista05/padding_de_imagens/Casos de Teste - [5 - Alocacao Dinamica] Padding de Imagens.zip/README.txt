Arquivo zip gerado em: 08/07/2021 21:00:02 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [5 - Alocação Dinâmica] Padding de Imagens