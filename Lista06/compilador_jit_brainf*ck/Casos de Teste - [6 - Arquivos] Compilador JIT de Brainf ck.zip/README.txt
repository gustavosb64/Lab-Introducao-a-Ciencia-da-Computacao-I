Arquivo zip gerado em: 27/07/2021 11:02:47 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [6 - Arquivos] Compilador JIT de Brainf*ck