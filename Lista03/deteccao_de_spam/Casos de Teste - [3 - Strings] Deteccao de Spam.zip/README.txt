Arquivo zip gerado em: 10/06/2021 23:08:13 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [3 - Strings] Detecção de Spam