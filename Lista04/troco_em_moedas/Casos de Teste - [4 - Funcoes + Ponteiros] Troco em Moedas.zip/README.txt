Arquivo zip gerado em: 30/06/2021 17:25:22 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [4 - Funções + Ponteiros] Troco em Moedas